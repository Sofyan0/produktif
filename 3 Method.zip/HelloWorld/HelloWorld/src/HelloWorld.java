/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ADI
 */
public class HelloWorld {
  
    public static void main(String args[]) {
       // TODO code application logic here
       System.out.println("Hello");
       System.out.println("nama Sofyan Priya Achmadi");
       System.out.println("Asal Situbondo");
       System.out.println("Umurku 19");
       System.out.println("Hobi saya Sepak Bola");
       
     
    
    
    
    
        
    }
    
}




