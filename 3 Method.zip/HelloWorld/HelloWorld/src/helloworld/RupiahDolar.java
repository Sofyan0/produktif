/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package helloworld;

/**
 *
 * @author ADI
 */
import java.util.Scanner;
public class RupiahDolar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       
       
            Scanner pilihan  = new Scanner(System.in);
        float dolar, rupiah, isi;
            System.out.println("Pilih Konversi : ");
            System.out.println("- - - - - - - - - - - -");
            System.out.println("1. Rupiah ke Dolar");
            System.out.println("2. Dolar ke Rupiah");
            System.out.println("- - - - - - - - - - - -");
            System.out.print("Masukkan Pilihanmu (1/2) : ");
            isi =   pilihan.nextFloat();
            if (isi == 1) {
                System.out.print("Berapa rupiah yang ingin kamu konversikan : ");
                rupiah =   pilihan.nextFloat();
                dolar = rupiah/15000;
                System.out.print("Konversi dari Rp."+ rupiah + "Adalah $"+dolar);
            } else if (isi == 2) {
                System.out.print("Berapa dolar yang ingin kamu konversikan : ");
                dolar =   pilihan.nextFloat();
                rupiah = dolar*15000;
                System.out.print("Konversi dari $"+ dolar + "Adalah Rp."+rupiah);
            } else {
                System.out.print("Maaf, Pilihan Anda Tidak Ada");
            }
    }
}