/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package helloworld;

/**
 *
 * @author ADI
 */
import java.util.Scanner;

public class HelloWorld {

   
     
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int panjang, lebar ;
        System.out.print("Maukan panjang: ");
        panjang = sc.nextInt();
        System.out.print("Masukan lebar: ");
        lebar = sc.nextInt();
        System.out.print("Nilai dari panjang: " + panjang);
        System.out.print("Nilai dari lebar:" + lebar);
        
        
    }        
}   
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
                
   
    